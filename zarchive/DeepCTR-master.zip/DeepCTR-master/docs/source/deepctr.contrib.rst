deepctr.contrib package
=======================

Submodules
----------

.. toctree::

   deepctr.contrib.rnn
   deepctr.contrib.utils

Module contents
---------------

.. automodule:: deepctr.contrib
    :members:
    :undoc-members:
    :show-inheritance:
