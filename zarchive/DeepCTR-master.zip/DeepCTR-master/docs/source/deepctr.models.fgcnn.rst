deepctr.models.fgcnn module
===========================

.. automodule:: deepctr.models.fgcnn
    :members:
    :no-undoc-members:
    :no-show-inheritance:
