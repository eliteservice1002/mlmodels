deepctr.models.nffm module
==========================

.. automodule:: deepctr.models.nffm
    :members:
    :no-undoc-members:
    :no-show-inheritance:
