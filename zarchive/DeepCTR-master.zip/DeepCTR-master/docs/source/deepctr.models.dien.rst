deepctr.models.dien module
==========================

.. automodule:: deepctr.models.dien
    :members:
    :no-undoc-members:
    :no-show-inheritance:
