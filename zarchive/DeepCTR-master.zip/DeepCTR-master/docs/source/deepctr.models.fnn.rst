deepctr.models.fnn module
=========================

.. automodule:: deepctr.models.fnn
    :members:
    :no-undoc-members:
    :no-show-inheritance:
