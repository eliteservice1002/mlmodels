deepctr.models package
======================

Submodules
----------

.. toctree::

   deepctr.models.afm
   deepctr.models.autoint
   deepctr.models.ccpm
   deepctr.models.dcn
   deepctr.models.deepfm
   deepctr.models.dien
   deepctr.models.din
   deepctr.models.dsin
   deepctr.models.fgcnn
   deepctr.models.fibinet
   deepctr.models.fnn
   deepctr.models.mlr
   deepctr.models.nffm
   deepctr.models.nfm
   deepctr.models.pnn
   deepctr.models.wdl
   deepctr.models.xdeepfm

Module contents
---------------

.. automodule:: deepctr.models
    :members:
    :undoc-members:
    :show-inheritance:
