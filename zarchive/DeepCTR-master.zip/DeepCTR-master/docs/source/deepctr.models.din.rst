deepctr.models.din module
=========================

.. automodule:: deepctr.models.din
    :members:
    :no-undoc-members:
    :no-show-inheritance:
