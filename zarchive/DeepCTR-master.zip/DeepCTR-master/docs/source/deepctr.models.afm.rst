deepctr.models.afm module
=========================

.. automodule:: deepctr.models.afm
    :members:
    :no-undoc-members:
    :no-show-inheritance:
