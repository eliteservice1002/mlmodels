deepctr.contrib.rnn module
==========================

.. automodule:: deepctr.contrib.rnn
    :members:
    :undoc-members:
    :show-inheritance:
