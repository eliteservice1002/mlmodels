deepctr.models.xdeepfm module
=============================

.. automodule:: deepctr.models.xdeepfm
    :members:
    :no-undoc-members:
    :no-show-inheritance:
