from .utils import check_version

__version__ = '0.7.0'
check_version(__version__)
